package threading;

public enum KochType {
    LEFT, RIGHT, BOTTOM
}
