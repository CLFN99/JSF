package depreciated;

public enum KochType {
    LEFT, RIGHT, BOTTOM
}
